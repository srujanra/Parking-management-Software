For importing the database ( like ER_diagram.png) into xammp sql:
    start xammp apache and mysql
    go to import section
    choose file
    download and select localhost.sql
    click on go
    now the database is imported